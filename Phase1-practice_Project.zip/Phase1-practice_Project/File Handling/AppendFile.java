package gitproject2;

//public class AppendFile {
	import java.io.FileWriter; 
	import java.io.IOException; 
	public class AppendFile { 
	public static void main(String[] args) { 
	// TODO Auto-generated method stub 
	String data ="This data is appended"; 
	try { 
	FileWriter output = new FileWriter("Thrinath.txt",true); output.write(data); 
	System.out.println("data appended successfully.."); 
	output.close(); 
	} catch (IOException e) { 
	System.out.println("file append error ...");

}
}
	}