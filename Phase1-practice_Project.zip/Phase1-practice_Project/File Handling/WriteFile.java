package gitproject2;

import java.io.FileWriter;
//public class WriteFile {
	import java.io.IOException; 
	public class WriteFile { 
	public static void main(String[] args) { 
	String data ="ganesh from kalasalingam university"; 
	try { 
	FileWriter output = new FileWriter("Vidhu.txt"); 
	output.write(data); 
	System.out.println("Data is written successfully"); 
	output.close(); 
	} catch (IOException e) { 
	System.out.println("File write error...."); 
	}}}


