package gitproject2;

	import java.util.Scanner;
	import java.util.regex.Matcher;
	import java.util.regex.Pattern;
	 
	public class Regularexpression {
	 public static void main(String[] args) {
	 Scanner s = new Scanner(System.in);
	 System.out.println("enter the email id");
	 String email = s.next();
	 // Pattern for matching email addresses
	 String patternString = "\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}\\b";
	 // Create a Pattern object
	 Pattern pattern = Pattern.compile(patternString);
	 // Create a Matcher object
	 Matcher matcher = pattern.matcher(email);
	 // Check if the email is valid
	 if (matcher.matches())
	 {
	 System.out.println("Valid email address");
	 } else
	 {
	 System.out.println("Invalid email address");
	 s.close(); 
	 
	}
	}


}
