package gitproject2;
	import java.util.Scanner;
	public class Calculator {
	 public static void main(String[] args)
	 {
	 char operator;
	 Double num1,num2,result;
	 
	 //Create an object scanner class
	 Scanner Sc = new java.util.Scanner(System.in);
	 
	 //Enter the operators
	 System.out.println("Enter the operator");
	 operator=Sc.next().charAt(0);
	 
	 //Enter the First value
	 System.out.println("Enter the first value");
	 num1=Sc.nextDouble();
	 
	 //Enter the Second value
	 System.out.println("Enter the Second value");
	 num2=Sc.nextDouble();
	 
	 switch(operator)
	 {
	 //Addition
	 case'+':
	 result=num1+num2;
	 System.out.println("Result:"+num1+"+"+num2+"="+result);
	 break;
	 
	 //Subtraction
	 case'-':
	 result=num1-num2;
	 System.out.println("Result:"+num1+"-"+num2+"="+result);
	 break;
	 
	 //Multiplication
	 case'*':
	 result=num1*num2;
	 System.out.println("Result:"+num1+"*"+num2+"="+result);
	 break;
	 
	 //division
	 case'/':
	 result=num1/num2;
	 System.out.println("Result:"+num1+"/"+num2+""+result);
	 break;
	 
	 
	 //Module
	 case'%':
	 result=num1%num2;
	 System.out.println("Result:"+num1+"%"+num2+"="+result);
	 break;
	 
	 //default
	 default:
	 System.out.println("invalid operator");
	 break;
	 }
	 Sc.close();
	 }
	}
