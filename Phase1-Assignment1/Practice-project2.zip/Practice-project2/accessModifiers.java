package Projects;

class defAccessSpecifier
{ 
  void display() 
     { 
         System.out.println("You are using default access specifier"); 
     } 
} 

  public class accessModifiers {

	public static void main(String[] args) {
		//default
		System.out.println("Default Access Specifier");
		defAccessSpecifier obj = new defAccessSpecifier(); 		  
        obj.display(); 

	}
}

//2. using private access specifiers
class priaccessspecifier 
{ 
 private void display() 
  { 
      System.out.println("You are using private access specifier"); 
  } 
} 

public class accessModifiers {

	public static void main(String[] args) {
		//private
		System.out.println("Private Access Specifier");
		priaccessspecifier  obj = new priaccessspecifier(); 
      //trying to access private method of another class 
        //obj.display();

	}
}

3. using protected access specifiers
// below code is to be included in proaccessspecifiers.java file
package Projects;

public class proaccessSpecifiers {

	protected void display() 
  { 
      System.out.println("This is protected access specifier"); 
  } 
}

//create another package
 // below code is to be included in accesssModifiers.java file
package Projects;

import Projects.*;

public class accessModifiers extends proaccessSpecifiers  {

	public static void main(String[] args) {
		accessModifiers obj = new accessModifiers ();   
	       obj.display();  
	}

}


//4. using public access specifiers
 // below code is to be included in pubaccessspecifiers.java file
package pack1;

public class pubaccessspecifiers {

	public void display() 
   { 
       System.out.println("This is Public Access Specifiers"); 
   } 
}

//create another package
// below code is to be included in accessModifiers.java file
package pack2;
import pack1.*;

public class accessSpecifiers4 {

	public static void main(String[] args) {
		
		pubaccessspecifiers obj = new pubaccessspecifiers(); 
       obj.display();  
		
	}
}



